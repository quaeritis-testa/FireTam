package com.sredstva.firetam;

public class Calculations extends MainActivity {



}
