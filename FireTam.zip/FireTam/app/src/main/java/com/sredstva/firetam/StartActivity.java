package com.sredstva.firetam;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class StartActivity extends AppCompatActivity {
    Button playGame;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start_activity);

        playGame = (Button)findViewById(R.id.startButton);

        playGame.setOnClickListener(v -> startActivity(new Intent(StartActivity.this, MainActivity.class)));
        }

}
